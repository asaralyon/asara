"use strict";(()=>{var e={};e.id=3002,e.ids=[3002],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},96434:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>x,patchFetch:()=>m,requestAsyncStorage:()=>g,routeModule:()=>c,serverHooks:()=>v,staticGenerationAsyncStorage:()=>h});var i={};r.r(i),r.d(i,{POST:()=>u});var n=r(73278),o=r(45002),s=r(54877),a=r(71309),p=r(63506),d=r(93154),l=r(36384);async function u(e){try{let{firstName:t,lastName:r,email:i,phone:n,password:o,role:s,profession:u,category:c,companyName:g,description:h,address:v,city:x,postalCode:m,professionalPhone:A,professionalEmail:f,website:y}=await e.json();if(await d.Z.user.findUnique({where:{email:i}}))return a.NextResponse.json({error:"Cet email est deja utilise"},{status:400});let b=await (0,p.hash)(o,12),R=`${t}-${r}`.toLowerCase().replace(/\s+/g,"-"),S=R,w=1;for(;await d.Z.professionalProfile.findUnique({where:{slug:S}});)S=`${R}-${w}`,w++;let C=await d.Z.user.create({data:{email:i,passwordHash:b,firstName:t,lastName:r,phone:n||null,role:s||"MEMBER",status:"PENDING",emailVerified:!1}});"PROFESSIONAL"===s&&await d.Z.professionalProfile.create({data:{userId:C.id,profession:u,category:c,companyName:g||null,description:h||null,address:v||null,city:x,postalCode:m,professionalPhone:A||null,professionalEmail:f||null,website:y||null,slug:S,isPublished:!1}});let q=l.vl.inscriptionPending(t,s||"MEMBER");return await (0,l.Cz)({to:i,subject:q.subject,html:q.html}),await (0,l.Cz)({to:"info@asara-lyon.fr",subject:`Nouvelle inscription - ${t} ${r}`,html:`
        <h2>Nouvelle inscription sur ASARA</h2>
        <p><strong>Nom:</strong> ${t} ${r}</p>
        <p><strong>Email:</strong> ${i}</p>
        <p><strong>Type:</strong> ${"PROFESSIONAL"===s?"Professionnel":"Membre"}</p>
        ${"PROFESSIONAL"===s?`<p><strong>Profession:</strong> ${u}</p>`:""}
        <p><a href="http://localhost:3000/admin/utilisateurs">Voir dans l'admin</a></p>
      `}),a.NextResponse.json({success:!0,message:"Inscription reussie",userId:C.id})}catch(e){return console.error("Registration error:",e),a.NextResponse.json({error:"Erreur lors de l inscription"},{status:500})}}let c=new n.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/auth/register/route",pathname:"/api/auth/register",filename:"route",bundlePath:"app/api/auth/register/route"},resolvedPagePath:"/Users/talebsafwan/Downloads/asara-lyon-v2/src/app/api/auth/register/route.ts",nextConfigOutput:"",userland:i}),{requestAsyncStorage:g,staticGenerationAsyncStorage:h,serverHooks:v}=c,x="/api/auth/register/route";function m(){return(0,s.patchFetch)({serverHooks:v,staticGenerationAsyncStorage:h})}},36384:(e,t,r)=>{r.d(t,{Cz:()=>n,vl:()=>o});let i=r(56742).createTransport({host:"mail.infomaniak.com",port:465,secure:!0,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD}});async function n({to:e,subject:t,html:r}){try{return await i.sendMail({from:process.env.SMTP_FROM,to:e,subject:t,html:r}),{success:!0}}catch(e){return console.error("Email error:",e),{success:!1,error:e}}}let o={inscriptionPending:(e,t)=>({subject:"Inscription recue - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2D8C3C; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bienvenue ${e} !</h2>
          <p>Nous avons bien recu votre demande d'inscription en tant que <strong>${"PROFESSIONAL"===t?"Professionnel":"Membre"}</strong>.</p>
          <p>Votre inscription est en cours de validation par notre equipe. Vous recevrez un email de confirmation une fois votre compte active.</p>
          <p>Si vous avez des questions, n'hesitez pas a nous contacter.</p>
          <br>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
          <p>Rue Leon Blum, 69150 Decines</p>
        </div>
      </div>
    `}),accountActivated:(e,t)=>({subject:"Compte active - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2D8C3C; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Felicitations ${e} !</h2>
          <p>Votre compte <strong>${"PROFESSIONAL"===t?"Professionnel":"Membre"}</strong> a ete active avec succes.</p>
          ${"PROFESSIONAL"===t?"<p>Votre profil est maintenant visible dans notre annuaire des professionnels.</p>":""}
          <p>Vous pouvez desormais vous connecter et acceder a votre espace membre.</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="http://localhost:3000/connexion" style="background: #2D8C3C; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Se connecter</a>
          </div>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
          <p>Rue Leon Blum, 69150 Decines</p>
        </div>
      </div>
    `}),accountSuspended:e=>({subject:"Compte suspendu - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2D8C3C; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bonjour ${e},</h2>
          <p>Votre compte a ete suspendu.</p>
          <p>Si vous pensez qu'il s'agit d'une erreur, veuillez nous contacter.</p>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
        </div>
      </div>
    `}),renewalReminder30:(e,t,r)=>({subject:"Votre adhesion expire dans 30 jours - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2D8C3C; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bonjour ${e},</h2>
          <p>Votre adhesion ASARA expire le <strong>${t}</strong>.</p>
          <p>Pour continuer a beneficier de tous nos services, pensez a renouveler votre adhesion (${r}).</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="http://localhost:3000/mon-compte" style="background: #2D8C3C; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Renouveler mon adhesion</a>
          </div>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
        </div>
      </div>
    `}),renewalReminder7:(e,t,r)=>({subject:"Urgent : Votre adhesion expire dans 7 jours - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #CE2027; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bonjour ${e},</h2>
          <p style="color: #CE2027;"><strong>Votre adhesion expire dans 7 jours !</strong></p>
          <p>Date d'expiration : <strong>${t}</strong></p>
          <p>Renouvelez maintenant pour eviter toute interruption de service (${r}).</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="http://localhost:3000/mon-compte" style="background: #CE2027; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Renouveler maintenant</a>
          </div>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
        </div>
      </div>
    `}),subscriptionExpired:(e,t)=>({subject:"Votre adhesion a expire - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #CE2027; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bonjour ${e},</h2>
          <p>Votre adhesion ASARA a expire.</p>
          ${"PROFESSIONAL"===t?"<p>Votre profil n'est plus visible dans l'annuaire.</p>":""}
          <p>Renouvelez des maintenant pour retrouver l'acces a tous nos services.</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="http://localhost:3000/adhesion" style="background: #2D8C3C; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Renouveler mon adhesion</a>
          </div>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
        </div>
      </div>
    `})}},93154:(e,t,r)=>{r.d(t,{Z:()=>n});let i=require("@prisma/client"),n=globalThis.prisma??new i.PrismaClient}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[9379,4833,1797,3506],()=>r(96434));module.exports=i})();