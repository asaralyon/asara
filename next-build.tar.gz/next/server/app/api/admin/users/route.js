"use strict";(()=>{var e={};e.id=2628,e.ids=[2628],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},31264:(e,t,r)=>{r.r(t),r.d(t,{originalPathname:()=>x,patchFetch:()=>m,requestAsyncStorage:()=>v,routeModule:()=>c,serverHooks:()=>h,staticGenerationAsyncStorage:()=>g});var n={};r.r(n),r.d(n,{DELETE:()=>l,PATCH:()=>u});var i=r(73278),s=r(45002),o=r(54877),a=r(71309),p=r(93154),d=r(36384);async function u(e){try{let{userId:t,action:r}=await e.json();if(!t||!r)return a.NextResponse.json({error:"Donnees manquantes"},{status:400});let n=await p.Z.user.findUnique({where:{id:t}});if(!n)return a.NextResponse.json({error:"Utilisateur non trouve"},{status:404});let i={};switch(r){case"approve":i={status:"ACTIVE"},await p.Z.professionalProfile.updateMany({where:{userId:t},data:{isPublished:!0,publishedAt:new Date}});let s=d.vl.accountActivated(n.firstName,n.role);await (0,d.Cz)({to:n.email,subject:s.subject,html:s.html});break;case"suspend":i={status:"SUSPENDED"},await p.Z.professionalProfile.updateMany({where:{userId:t},data:{isPublished:!1}});let o=d.vl.accountSuspended(n.firstName);await (0,d.Cz)({to:n.email,subject:o.subject,html:o.html});break;case"activate":i={status:"ACTIVE"},await p.Z.professionalProfile.updateMany({where:{userId:t},data:{isPublished:!0}});let u=d.vl.accountActivated(n.firstName,n.role);await (0,d.Cz)({to:n.email,subject:u.subject,html:u.html});break;default:return a.NextResponse.json({error:"Action non valide"},{status:400})}let l=await p.Z.user.update({where:{id:t},data:i});return a.NextResponse.json({success:!0,user:l})}catch(e){return console.error("Admin error:",e),a.NextResponse.json({error:"Erreur serveur"},{status:500})}}async function l(e){try{let{userId:t}=await e.json();if(!t)return a.NextResponse.json({error:"ID utilisateur manquant"},{status:400});return await p.Z.professionalProfile.deleteMany({where:{userId:t}}),await p.Z.user.delete({where:{id:t}}),a.NextResponse.json({success:!0})}catch(e){return console.error("Delete error:",e),a.NextResponse.json({error:"Erreur serveur"},{status:500})}}let c=new i.AppRouteRouteModule({definition:{kind:s.x.APP_ROUTE,page:"/api/admin/users/route",pathname:"/api/admin/users",filename:"route",bundlePath:"app/api/admin/users/route"},resolvedPagePath:"/Users/talebsafwan/Downloads/asara-lyon-v2/src/app/api/admin/users/route.ts",nextConfigOutput:"",userland:n}),{requestAsyncStorage:v,staticGenerationAsyncStorage:g,serverHooks:h}=c,x="/api/admin/users/route";function m(){return(0,o.patchFetch)({serverHooks:h,staticGenerationAsyncStorage:g})}},36384:(e,t,r)=>{r.d(t,{Cz:()=>i,vl:()=>s});let n=r(56742).createTransport({host:"mail.infomaniak.com",port:465,secure:!0,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD}});async function i({to:e,subject:t,html:r}){try{return await n.sendMail({from:process.env.SMTP_FROM,to:e,subject:t,html:r}),{success:!0}}catch(e){return console.error("Email error:",e),{success:!1,error:e}}}let s={inscriptionPending:(e,t)=>({subject:"Inscription recue - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2D8C3C; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bienvenue ${e} !</h2>
          <p>Nous avons bien recu votre demande d'inscription en tant que <strong>${"PROFESSIONAL"===t?"Professionnel":"Membre"}</strong>.</p>
          <p>Votre inscription est en cours de validation par notre equipe. Vous recevrez un email de confirmation une fois votre compte active.</p>
          <p>Si vous avez des questions, n'hesitez pas a nous contacter.</p>
          <br>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
          <p>Rue Leon Blum, 69150 Decines</p>
        </div>
      </div>
    `}),accountActivated:(e,t)=>({subject:"Compte active - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2D8C3C; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Felicitations ${e} !</h2>
          <p>Votre compte <strong>${"PROFESSIONAL"===t?"Professionnel":"Membre"}</strong> a ete active avec succes.</p>
          ${"PROFESSIONAL"===t?"<p>Votre profil est maintenant visible dans notre annuaire des professionnels.</p>":""}
          <p>Vous pouvez desormais vous connecter et acceder a votre espace membre.</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="http://localhost:3000/connexion" style="background: #2D8C3C; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Se connecter</a>
          </div>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
          <p>Rue Leon Blum, 69150 Decines</p>
        </div>
      </div>
    `}),accountSuspended:e=>({subject:"Compte suspendu - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2D8C3C; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bonjour ${e},</h2>
          <p>Votre compte a ete suspendu.</p>
          <p>Si vous pensez qu'il s'agit d'une erreur, veuillez nous contacter.</p>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
        </div>
      </div>
    `}),renewalReminder30:(e,t,r)=>({subject:"Votre adhesion expire dans 30 jours - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2D8C3C; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bonjour ${e},</h2>
          <p>Votre adhesion ASARA expire le <strong>${t}</strong>.</p>
          <p>Pour continuer a beneficier de tous nos services, pensez a renouveler votre adhesion (${r}).</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="http://localhost:3000/mon-compte" style="background: #2D8C3C; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Renouveler mon adhesion</a>
          </div>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
        </div>
      </div>
    `}),renewalReminder7:(e,t,r)=>({subject:"Urgent : Votre adhesion expire dans 7 jours - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #CE2027; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bonjour ${e},</h2>
          <p style="color: #CE2027;"><strong>Votre adhesion expire dans 7 jours !</strong></p>
          <p>Date d'expiration : <strong>${t}</strong></p>
          <p>Renouvelez maintenant pour eviter toute interruption de service (${r}).</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="http://localhost:3000/mon-compte" style="background: #CE2027; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Renouveler maintenant</a>
          </div>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
        </div>
      </div>
    `}),subscriptionExpired:(e,t)=>({subject:"Votre adhesion a expire - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #CE2027; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bonjour ${e},</h2>
          <p>Votre adhesion ASARA a expire.</p>
          ${"PROFESSIONAL"===t?"<p>Votre profil n'est plus visible dans l'annuaire.</p>":""}
          <p>Renouvelez des maintenant pour retrouver l'acces a tous nos services.</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="http://localhost:3000/adhesion" style="background: #2D8C3C; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Renouveler mon adhesion</a>
          </div>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
        </div>
      </div>
    `})}},93154:(e,t,r)=>{r.d(t,{Z:()=>i});let n=require("@prisma/client"),i=globalThis.prisma??new n.PrismaClient}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),n=t.X(0,[9379,4833,1797],()=>r(31264));module.exports=n})();