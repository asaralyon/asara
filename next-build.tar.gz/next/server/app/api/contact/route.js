"use strict";(()=>{var e={};e.id=386,e.ids=[386],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},15679:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>g,patchFetch:()=>h,requestAsyncStorage:()=>l,routeModule:()=>c,serverHooks:()=>m,staticGenerationAsyncStorage:()=>d});var s={};t.r(s),t.d(s,{POST:()=>u});var o=t(73278),n=t(45002),a=t(54877),p=t(71309),i=t(56742);async function u(e){try{let{name:r,email:t,phone:s,subject:o,message:n}=await e.json();if(!r||!t||!o||!n)return p.NextResponse.json({error:"Tous les champs obligatoires doivent etre remplis"},{status:400});let a={information:"Demande d information",adhesion:"Question sur l adhesion",annuaire:"Question sur l annuaire",evenement:"Question sur les evenements",partenariat:"Proposition de partenariat",autre:"Autre"},u=i.createTransport({host:"mail.infomaniak.com",port:465,secure:!0,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD}});return await u.sendMail({from:process.env.SMTP_FROM,to:"info@asara-lyon.fr",replyTo:t,subject:`[Contact ASARA] ${a[o]||o}`,html:`
        <h2>Nouveau message de contact</h2>
        <p><strong>Nom:</strong> ${r}</p>
        <p><strong>Email:</strong> ${t}</p>
        <p><strong>Telephone:</strong> ${s||"Non renseigne"}</p>
        <p><strong>Sujet:</strong> ${a[o]||o}</p>
        <hr>
        <p><strong>Message:</strong></p>
        <p>${n.replace(/\n/g,"<br>")}</p>
      `}),await u.sendMail({from:process.env.SMTP_FROM,to:t,subject:"Confirmation de votre message - ASARA",html:`
        <h2>Merci de nous avoir contacte !</h2>
        <p>Bonjour ${r},</p>
        <p>Nous avons bien recu votre message concernant : <strong>${a[o]||o}</strong></p>
        <p>Notre equipe vous repondra dans les plus brefs delais.</p>
        <br>
        <p>Cordialement,</p>
        <p><strong>L'equipe ASARA</strong></p>
        <hr>
        <p style="color: #666; font-size: 12px;">
          Association des Syriens d'Auvergne Rhone-Alpes<br>
          Rue Leon Blum, 69150 Decines<br>
          info@asara-lyon.fr
        </p>
      `}),p.NextResponse.json({success:!0})}catch(e){return console.error("Contact error:",e),p.NextResponse.json({error:"Erreur lors de l envoi du message"},{status:500})}}let c=new o.AppRouteRouteModule({definition:{kind:n.x.APP_ROUTE,page:"/api/contact/route",pathname:"/api/contact",filename:"route",bundlePath:"app/api/contact/route"},resolvedPagePath:"/Users/talebsafwan/Downloads/asara-lyon-v2/src/app/api/contact/route.ts",nextConfigOutput:"",userland:s}),{requestAsyncStorage:l,staticGenerationAsyncStorage:d,serverHooks:m}=c,g="/api/contact/route";function h(){return(0,a.patchFetch)({serverHooks:m,staticGenerationAsyncStorage:d})}}};var r=require("../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),s=r.X(0,[9379,4833,1797],()=>t(15679));module.exports=s})();