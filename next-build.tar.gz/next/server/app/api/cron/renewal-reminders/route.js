"use strict";(()=>{var e={};e.id=1367,e.ids=[1367],e.modules={20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},61282:e=>{e.exports=require("child_process")},84770:e=>{e.exports=require("crypto")},80665:e=>{e.exports=require("dns")},17702:e=>{e.exports=require("events")},92048:e=>{e.exports=require("fs")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},98216:e=>{e.exports=require("net")},19801:e=>{e.exports=require("os")},55315:e=>{e.exports=require("path")},76162:e=>{e.exports=require("stream")},82452:e=>{e.exports=require("tls")},17360:e=>{e.exports=require("url")},21764:e=>{e.exports=require("util")},71568:e=>{e.exports=require("zlib")},30464:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>x,patchFetch:()=>h,requestAsyncStorage:()=>c,routeModule:()=>u,serverHooks:()=>v,staticGenerationAsyncStorage:()=>g});var n={};t.r(n),t.d(n,{GET:()=>l});var i=t(73278),o=t(45002),s=t(54877),a=t(71309),d=t(93154),p=t(36384);async function l(e){if(e.headers.get("authorization")!==`Bearer ${process.env.CRON_SECRET}`)return a.NextResponse.json({error:"Non autorise"},{status:401});try{let e=new Date,r=new Date(e.getTime()+2592e6),t=new Date(e.getTime()+6048e5),n=await d.Z.subscription.findMany({where:{status:"ACTIVE",currentPeriodEnd:{gte:new Date(r.getTime()-864e5),lte:r}},include:{user:!0}}),i=await d.Z.subscription.findMany({where:{status:"ACTIVE",currentPeriodEnd:{gte:new Date(t.getTime()-864e5),lte:t}},include:{user:!0}}),o=await d.Z.subscription.findMany({where:{status:"ACTIVE",currentPeriodEnd:{lte:e}},include:{user:!0}}),s=0;for(let e of n){let r="PROFESSIONAL"===e.type?"100 EUR":"15 EUR",t=p.vl.renewalReminder30(e.user.firstName,e.currentPeriodEnd.toLocaleDateString("fr-FR"),r);await (0,p.Cz)({to:e.user.email,...t}),s++}for(let e of i){let r="PROFESSIONAL"===e.type?"100 EUR":"15 EUR",t=p.vl.renewalReminder7(e.user.firstName,e.currentPeriodEnd.toLocaleDateString("fr-FR"),r);await (0,p.Cz)({to:e.user.email,...t}),s++}for(let e of o){await d.Z.subscription.update({where:{id:e.id},data:{status:"EXPIRED"}}),await d.Z.user.update({where:{id:e.userId},data:{status:"EXPIRED"}}),await d.Z.professionalProfile.updateMany({where:{userId:e.userId},data:{isPublished:!1}});let r=p.vl.subscriptionExpired(e.user.firstName,e.user.role);await (0,p.Cz)({to:e.user.email,...r}),s++}return a.NextResponse.json({success:!0,emailsSent:s,details:{reminder30:n.length,reminder7:i.length,expired:o.length}})}catch(e){return console.error("CRON error:",e),a.NextResponse.json({error:"Erreur serveur"},{status:500})}}let u=new i.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/cron/renewal-reminders/route",pathname:"/api/cron/renewal-reminders",filename:"route",bundlePath:"app/api/cron/renewal-reminders/route"},resolvedPagePath:"/Users/talebsafwan/Downloads/asara-lyon-v2/src/app/api/cron/renewal-reminders/route.ts",nextConfigOutput:"",userland:n}),{requestAsyncStorage:c,staticGenerationAsyncStorage:g,serverHooks:v}=u,x="/api/cron/renewal-reminders/route";function h(){return(0,s.patchFetch)({serverHooks:v,staticGenerationAsyncStorage:g})}},36384:(e,r,t)=>{t.d(r,{Cz:()=>i,vl:()=>o});let n=t(56742).createTransport({host:"mail.infomaniak.com",port:465,secure:!0,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD}});async function i({to:e,subject:r,html:t}){try{return await n.sendMail({from:process.env.SMTP_FROM,to:e,subject:r,html:t}),{success:!0}}catch(e){return console.error("Email error:",e),{success:!1,error:e}}}let o={inscriptionPending:(e,r)=>({subject:"Inscription recue - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2D8C3C; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bienvenue ${e} !</h2>
          <p>Nous avons bien recu votre demande d'inscription en tant que <strong>${"PROFESSIONAL"===r?"Professionnel":"Membre"}</strong>.</p>
          <p>Votre inscription est en cours de validation par notre equipe. Vous recevrez un email de confirmation une fois votre compte active.</p>
          <p>Si vous avez des questions, n'hesitez pas a nous contacter.</p>
          <br>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
          <p>Rue Leon Blum, 69150 Decines</p>
        </div>
      </div>
    `}),accountActivated:(e,r)=>({subject:"Compte active - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2D8C3C; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Felicitations ${e} !</h2>
          <p>Votre compte <strong>${"PROFESSIONAL"===r?"Professionnel":"Membre"}</strong> a ete active avec succes.</p>
          ${"PROFESSIONAL"===r?"<p>Votre profil est maintenant visible dans notre annuaire des professionnels.</p>":""}
          <p>Vous pouvez desormais vous connecter et acceder a votre espace membre.</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="http://localhost:3000/connexion" style="background: #2D8C3C; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Se connecter</a>
          </div>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
          <p>Rue Leon Blum, 69150 Decines</p>
        </div>
      </div>
    `}),accountSuspended:e=>({subject:"Compte suspendu - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2D8C3C; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bonjour ${e},</h2>
          <p>Votre compte a ete suspendu.</p>
          <p>Si vous pensez qu'il s'agit d'une erreur, veuillez nous contacter.</p>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
        </div>
      </div>
    `}),renewalReminder30:(e,r,t)=>({subject:"Votre adhesion expire dans 30 jours - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #2D8C3C; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bonjour ${e},</h2>
          <p>Votre adhesion ASARA expire le <strong>${r}</strong>.</p>
          <p>Pour continuer a beneficier de tous nos services, pensez a renouveler votre adhesion (${t}).</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="http://localhost:3000/mon-compte" style="background: #2D8C3C; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Renouveler mon adhesion</a>
          </div>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
        </div>
      </div>
    `}),renewalReminder7:(e,r,t)=>({subject:"Urgent : Votre adhesion expire dans 7 jours - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #CE2027; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bonjour ${e},</h2>
          <p style="color: #CE2027;"><strong>Votre adhesion expire dans 7 jours !</strong></p>
          <p>Date d'expiration : <strong>${r}</strong></p>
          <p>Renouvelez maintenant pour eviter toute interruption de service (${t}).</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="http://localhost:3000/mon-compte" style="background: #CE2027; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Renouveler maintenant</a>
          </div>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
        </div>
      </div>
    `}),subscriptionExpired:(e,r)=>({subject:"Votre adhesion a expire - ASARA",html:`
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: #CE2027; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">ASARA</h1>
        </div>
        <div style="padding: 30px; background: #f9f9f9;">
          <h2>Bonjour ${e},</h2>
          <p>Votre adhesion ASARA a expire.</p>
          ${"PROFESSIONAL"===r?"<p>Votre profil n'est plus visible dans l'annuaire.</p>":""}
          <p>Renouvelez des maintenant pour retrouver l'acces a tous nos services.</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="http://localhost:3000/adhesion" style="background: #2D8C3C; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-weight: bold;">Renouveler mon adhesion</a>
          </div>
          <p>Cordialement,</p>
          <p><strong>L'equipe ASARA</strong></p>
        </div>
        <div style="background: #333; color: #999; padding: 20px; text-align: center; font-size: 12px;">
          <p>Association des Syriens d'Auvergne Rhone-Alpes</p>
        </div>
      </div>
    `})}},93154:(e,r,t)=>{t.d(r,{Z:()=>i});let n=require("@prisma/client"),i=globalThis.prisma??new n.PrismaClient}};var r=require("../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),n=r.X(0,[9379,4833,1797],()=>t(30464));module.exports=n})();